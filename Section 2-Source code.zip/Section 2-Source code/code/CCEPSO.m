function [gBestScore, gBest, cg_curve] = CCEPSO(N, Max_iteration, lb, ub, dim, fobj)
% CCEPSO — PSO + Competitive Cluster Elimination (single-module plug-in)
% Signature identical to your PSO.m
%
% No extra evaluations. CCE is called AFTER each iteration's evaluations,
% so restarted particles get evaluated next iteration naturally.
% Author: Junbo Jacob Lian

    % ---- PSO params (same as your baseline)
    Vmax = 2; noP = N;
    wMax = 0.9; wMin = 0.2; c1 = 2; c2 = 2;

    % ---- ensure lb/ub row
    if isscalar(lb), lb = lb*ones(1,dim); end
    if isscalar(ub), ub = ub*ones(1,dim); end

    iter       = Max_iteration;
    vel        = zeros(noP, dim);
    pBestScore = inf(noP, 1);
    pBest      = zeros(noP, dim);
    gBest      = zeros(1, dim);
    cg_curve   = zeros(1, iter);

    pos        = initialization(noP, dim, ub, lb);
    gBestScore = inf;

    % ---- CCE state & opts
    cce_state = struct('t',1);
    cce_opts  = struct('tau',3,'K',[],'steps',5,'rho',0.7,'pick','min',...
                       'keep_one',true,'avoid_best',true);

    for l = 1:iter
        fvals = zeros(noP,1);
        % ===== evaluate & update bests
        for i = 1:noP
            % boundary
            Flag4ub  = pos(i,:)>ub; Flag4lb = pos(i,:)<lb;
            pos(i,:) = (pos(i,:).*(~(Flag4ub+Flag4lb))) + ub.*Flag4ub + lb.*Flag4lb;

            f = fobj(pos(i,:));
            fvals(i) = f;

            if f < pBestScore(i)
                pBestScore(i) = f; pBest(i,:) = pos(i,:);
            end
            if f < gBestScore
                gBestScore = f; gBest = pos(i,:);
            end
        end

        % ===== PSO update
        w = wMax - l * ((wMax - wMin) / iter);
        for i = 1:noP
            r1 = rand(1,dim); r2 = rand(1,dim);
            vel(i,:) = w*vel(i,:) ...
                     + c1*r1.*(pBest(i,:)-pos(i,:)) ...
                     + c2*r2.*(gBest      -pos(i,:));
            % clamp & move
            vel(i,:) = max(min(vel(i,:), Vmax), -Vmax);
            pos(i,:) = pos(i,:) + vel(i,:);
        end

        % ===== plug-in: Competitive Cluster Elimination (after eval/update)
        [pos_new, cce_state, info] = CCE(pos, fvals, lb, ub, cce_state, cce_opts);
        if info.did_eliminate
            % for replaced particles: reset velocity & pBest so they can really explore
            idx = info.replaced_idx(:)';
            vel(idx,:)       = 0;
            pBest(idx,:)     = pos_new(idx,:);
            pBestScore(idx)  = inf;
        end
        pos = pos_new;

        cg_curve(l) = gBestScore;
    end
end

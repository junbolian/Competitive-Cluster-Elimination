function [fitnessBestP,bestP,Convergence_curve] = CCEJADE(SearchAgents_no,Gmax,lb,ub,dim,fobj)
% CCEJADE — JADE + Competitive Cluster Elimination (evaluation-neutral)
% Signature:
%   [fitnessBestP,bestP,Convergence_curve] = CCEJADE(N, MaxIt, lb, ub, dim, fobj)
%
% Notes
% - 调用时机：每代完成 “选择 + 记忆更新” 后，调用 CCE() 改写位置，但不调用目标函数
% - 评价中立：被替换个体在下一代由 JADE 正常评估一次，不额外增加评估。
% - 依赖：同目录下需有 CCE.m；可选的 cauchyrnd()（若没有会自动回退到解析公式）。
%
% 全局：若你在主程序里设置了全局 CCE_OPTS，则本函数将读取它；
%       否则使用下面的默认参数。

    % ---------- bounds as row-vectors ----------
    if isscalar(ub), ub = repmat(ub, 1, dim); end
    if isscalar(lb), lb = repmat(lb, 1, dim); end
    lu = [lb; ub];

    % ---------- CCE options (global or defaults) ----------
    global CCE_OPTS
    if isempty(CCE_OPTS) || ~isstruct(CCE_OPTS)
        opts = struct('tau',2,'rho',0.9,'K',[], 'steps',5, ...
                      'pick','min','avoid_best',true,'keep_one',true);
    else
        opts = CCE_OPTS;
        if ~isfield(opts,'tau'),        opts.tau = 2;        end
        if ~isfield(opts,'rho'),        opts.rho = 0.9;      end
        if ~isfield(opts,'K'),          opts.K   = [];       end
        if ~isfield(opts,'steps'),      opts.steps = 5;      end
        if ~isfield(opts,'pick'),       opts.pick  = 'min';  end
        if ~isfield(opts,'avoid_best'), opts.avoid_best = true; end
        if ~isfield(opts,'keep_one'),   opts.keep_one   = true; end
    end
    cce_state = struct('t',1);   % CCE 内部代计数

    % ---------- JADE parameters ----------
    c   = 1/10;            % memory update learning rate
    p   = 0.05;            % top-p 比例
    top = max(1, floor(p*SearchAgents_no));  % 保证至少1个
    A   = [];              % archive

    % 历史均值
    uCR = 0.5;
    uF  = 0.5;

    % ---------- initialise population ----------
    P = repmat(lu(1, :), SearchAgents_no, 1) + ...
        rand(SearchAgents_no, dim) .* (repmat(lu(2, :) - lu(1, :), SearchAgents_no, 1));

    fitnessP = zeros(1,SearchAgents_no);
    for i=1:SearchAgents_no
        fitnessP(i) = fobj(P(i,:));
    end
    [fitnessBestP, indexBestP] = min(fitnessP);
    bestP = P(indexBestP,:);

    Convergence_curve = zeros(1,Gmax);
    G = 0;

    % ======================== main loop ========================
    while G < Gmax

        % ---- 每代开头：重算全体适应度 + 采样个体化参数 CR/F ----
        CR = zeros(1,SearchAgents_no);
        Fv = zeros(1,SearchAgents_no);  % 个体化 F
        for i=1:SearchAgents_no
            fitnessP(i) = fobj(P(i,:));

            % CR ~ N(uCR,0.1^2) 截断到 [0,1]
            CR(i) = normrnd(uCR, 0.1);
            while (CR(i)>1 || CR(i)<0)
                CR(i) = normrnd(uCR, 0.1);
            end

            % F ~ Cauchy(uF,0.1)，截断到 (0,1]
            Fi = cauchy_draw(uF, 0.1);
            Fi = min(1, Fi);
            while (Fi <= 0)
                Fi = cauchy_draw(uF, 0.1);
                Fi = min(1, Fi);
            end
            Fv(i) = Fi;
        end

        % ---- 选出前 p 的个体（用于 current-to-pbest/1）----
        [~, indexSortP] = sort(fitnessP);
        % 防止 top 超过种群或为 0
        tt = min(top, SearchAgents_no);
        bestTopP = P(indexSortP(1:tt), :);
        [fitnessBestP, indexBestP] = min(fitnessP);
        bestP = P(indexBestP,:);

        % ---- 变异：DE/current-to-pbest/1 ----
        V = zeros(SearchAgents_no, dim);
        for i=1:SearchAgents_no
            % Xpbest from top-p
            k0 = randi(tt);
            Xpbest = bestTopP(k0,:);

            % P1 from P (≠ i)
            k1 = randi(SearchAgents_no);
            while k1 == i
                k1 = randi(SearchAgents_no);
            end
            P1 = P(k1,:);

            % P2 from P ∪ A, 与 i、k1 不同；若集合过小，兜底从 P 里再取
            PandA = [P; A];
            numPA = size(PandA, 1);
            if numPA < 2
                % 极端情况下，A 为空且 P=1；兜底复制一份
                PandA = [PandA; P];
                numPA = size(PandA,1);
            end
            k2 = randi(numPA);
            trial = 0;
            while (k2 == i || k2 == k1) && trial < 8
                k2 = randi(numPA);
                trial = trial + 1;
            end
            if k2 == i || k2 == k1
                % 仍冲突则从 P 里再选一个不同于 i/k1 的
                k2 = randi(SearchAgents_no);
                while (k2 == i || k2 == k1)
                    k2 = randi(SearchAgents_no);
                end
                P2 = P(k2,:);
            else
                P2 = PandA(k2,:);
            end

            % 变异向量
            Fi = Fv(i);
            V(i,:) = P(i,:) + Fi*(Xpbest - P(i,:)) + Fi*(P1 - P2);
        end

        % ---- 交叉 ----
        U = P;
        for i=1:SearchAgents_no
            jrand = randi([1,dim]);
            for j=1:dim
                if (rand <= CR(i) || j==jrand)
                    U(i,j) = V(i,j);
                else
                    U(i,j) = P(i,j);
                end
            end
        end

        % ---- 边界处理（越界重采样）----
        for i=1:SearchAgents_no
            for j=1:dim
                if U(i,j)>ub(j) || U(i,j)<lb(j)
                    U(i,j) = lb(j) + rand*(ub(j)-lb(j));
                end
            end
        end

        % ---- 选择 + 更新 archive + 收集成功参数 ----
        fitnessU = zeros(1,SearchAgents_no);
        Scr = []; Sf = [];
        for i=1:SearchAgents_no
            fitnessU(i) = fobj(U(i,:));
            if fitnessU(i) < fitnessP(i)
                A = [A; P(i,:)];          % 淘汰者入 A
                P(i,:) = U(i,:);          % 接受新解
                fitnessP(i) = fitnessU(i);
                Scr(end+1) = CR(i);       %#ok<AGROW>
                Sf(end+1)  = Fv(i);       %#ok<AGROW>

                if fitnessU(i) < fitnessBestP
                    fitnessBestP = fitnessU(i);
                    bestP = U(i,:);
                end
            end
        end

        % ---- 控制 A 的规模不超过 NP ----
        tA = size(A,1);
        if tA > SearchAgents_no
            idxRem = randperm(tA, tA-SearchAgents_no);
            A(idxRem,:) = [];
        end

        % ---- 自适应参数更新（稳健版：等权重）----
        if ~isempty(Scr) && ~isempty(Sf)
            n = min(numel(Scr), numel(Sf));
            w = ones(n,1) / n;                         % 等权
            uCR = (1-c)*uCR + c * sum(w .* Scr(1:n)'); % row/col 对齐
            denom = sum(w .* Sf(1:n)');
            if denom <= eps
                newSf = uF;
            else
                newSf = sum(w .* (Sf(1:n)'.^2)) / denom; % Lehmer mean
            end
            uF  = (1-c)*uF + c * newSf;
        end

        % ========== CCE 插入点（评价中立）==========
        % 不产生新的评估；只改位置，下一代由 JADE 正常评估
        [P2, cce_state, info] = CCE(P, fitnessP', lb, ub, cce_state, opts);
        if info.did_eliminate
            P = P2;   % 无需置 inf；JADE 下一代会重算 fitnessP
        end

        % ---- 记录收敛曲线 ----
        G = G + 1;
        Convergence_curve(G) = fitnessBestP;
    end
end

% =============== Helper: robust Cauchy sampler =================
function y = cauchy_draw(mu, gamma)
% 优先调用用户环境的 cauchyrnd(mu, gamma, 1, 1)；若不可用，则用解析公式回退
    if exist('cauchyrnd','file') == 2
        y = cauchyrnd(mu, gamma, 1, 1);  % 显式给尺寸，避免某些实现默认返回矩阵
    else
        % 回退：X = mu + gamma * tan(pi*(U-0.5)), U~Uniform(0,1)
        u = rand - 0.5;
        y = mu + gamma * tan(pi*u);
    end
end

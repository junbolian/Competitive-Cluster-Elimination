function [fitnessBestX, bestX, Convergence_curve] = CCESHADE(SearchAgents_no, Gmax, lb, ub, dim, fobj)
% CCESHADE — SHADE + Competitive Cluster Elimination (evaluation-neutral)
% Signature identical to your SHADE:
%   [fitnessBestX, bestX, Convergence_curve] = CCESHADE(N, MaxIt, lb, ub, dim, fobj)
% Author: Junbo Jacob Lian
%
% Notes:
% - CCE 在每代 selection/memory 更新之后调用。
% - 对被替换个体：设 fitness(i)=Inf，防止下一代用“旧适应度”参与选择，
%   同时不增加任何评估（evaluation-neutral）。

if (max(size(ub)) == 1)
    ub = ub .* ones(1, dim);
    lb = lb .* ones(1, dim);
end

% ---------- CCE options ----------
global CCE_OPTS
if isempty(CCE_OPTS) || ~isstruct(CCE_OPTS)
    opts = struct('tau',2,'rho',0.9,'K',[], 'steps',5, ...
                  'pick','min','avoid_best',true,'keep_one',true);
else
    opts = CCE_OPTS;
    if ~isfield(opts,'tau'), opts.tau = 2; end
    if ~isfield(opts,'rho'), opts.rho = 0.9; end
    if ~isfield(opts,'K'),   opts.K   = []; end
    if ~isfield(opts,'steps'),opts.steps=5; end
    if ~isfield(opts,'pick'), opts.pick='min'; end
    if ~isfield(opts,'avoid_best'), opts.avoid_best=true; end
    if ~isfield(opts,'keep_one'),   opts.keep_one=true; end
end
cce_state = struct('t',1);

H  = SearchAgents_no;
MCR = 0.5 * ones(H, 1);
MF  = 0.5 * ones(H, 1);
A   = [];
B   = [];

% init population
x = repmat(lb, SearchAgents_no, 1) + rand(SearchAgents_no, dim) .* ...
    (repmat(ub - lb, SearchAgents_no, 1));
fitness = zeros(1, SearchAgents_no);
for i = 1:SearchAgents_no
    fitness(i) = fobj(x(i, :));
end

Convergence_curve = zeros(1, Gmax);
q = 1;
G = 0;

while G < Gmax
    [~, I] = sort(fitness);
    SCR = []; SF = []; w = []; B = [];

    pmin = 2 / SearchAgents_no;

    % 逐个体生成trial并选择
    for i = 1:SearchAgents_no
        r = randi(H);
        CR(i) = normrnd(MCR(r), 0.1); CR(i) = min(max(CR(i),0),1);
        F(i)  = cauchyrnd(MF(r), 0.1); F(i) = min(F(i),1);
        while (F(i) <= 0)
            F(i) = cauchyrnd(MF(r),0.1); F(i) = min(F(i),1);
        end

        p  = unifrnd(pmin, 0.2);
        p0 = max(1, round(p * SearchAgents_no));
        temp1 = floor(rand * p0) + 1;

        r1 = floor(rand * SearchAgents_no) + 1;
        while r1 == i
            r1 = floor(rand * SearchAgents_no) + 1;
        end
        S = [x; A];
        rS = size(S,1);
        r2 = floor(rand * rS) + 1;
        while r2 == i || r2 == r1
            r2 = floor(rand * rS) + 1;
        end

        v = x(i, :) + F(i) * (x(I(temp1), :) - x(i, :)) + F(i) * (x(r1, :) - S(r2, :));
        % 修正越界
        v = min(max(v, lb), ub);

        % 二项式交叉
        newx = x(i,:);
        jrand = floor(rand * dim) + 1;
        crossMask = (rand(1,dim) < CR(i));
        crossMask(jrand) = true;
        newx(crossMask) = v(crossMask);

        fnew = fobj(newx);

        if fnew < fitness(i)
            A = [A; x(i,:)];
            B = [B; fnew, fitness(i)];
            SCR = [SCR; CR(i)];
            SF  = [SF;  F(i)];
            x(i,:) = newx;
            fitness(i) = fnew;
        end
    end

    % 控制 A 大小
    a = size(A,1);
    while a > SearchAgents_no
        sel = floor(rand(a - SearchAgents_no, 1) * a) + 1;
        A(sel,:) = [];
        a = size(A,1);
    end

    % 更新记忆
    if ~isempty(SCR) && ~isempty(SF)
        b = abs(B(:,2) - B(:,1));
        if sum(b) > 0
            w = b ./ sum(b);
            MCR(q) = sum(w .* SCR);
            MF(q)  = sum(w .* (SF.^2)) / sum(w .* SF);
            q = q + 1; if q > H, q = 1; end
        end
    end

    % ================= CCE 插入点 =================
    [X2, cce_state, info] = CCE(x, fitness', lb, ub, cce_state, opts);
    if info.did_eliminate
        x = X2;
        % 关键：父代位置已变更，旧fitness无效，置Inf避免下一代比较使用旧值
        fitness(info.replaced_idx) = Inf;
    end

    % 记录收敛
    G = G + 1;
    [fitnessBestX, idx] = min(fitness);
    bestX = x(idx,:);
    Convergence_curve(G) = fitnessBestX;
end
end

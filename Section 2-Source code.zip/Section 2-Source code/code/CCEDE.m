function [BestScore, BestPos, BestCost] = CCEDE(nPop, MaxIt, VarMin, VarMax, nVar, CostFunction)
% CCEDE — DE + Competitive Cluster Elimination (single-module plug-in)
% Signature identical to your DE.m
%
% No extra evaluations. CCE is called AFTER selection each generation;
% replaced individuals have Cost=inf (so next selection is consistent).
% Author: Junbo Jacob Lian

    VarSize = [1 nVar];
    if isscalar(VarMin), VarMin = repmat(VarMin,1,nVar); end
    if isscalar(VarMax), VarMax = repmat(VarMax,1,nVar); end
    lo = VarMin; hi = VarMax; range = hi - lo;

    % ---- DE params
    F  = 0.5;
    pCR = 0.9;

    % ---- init
    BestSol.Position = []; BestSol.Cost = inf;
    pop = repmat(struct('Position',[],'Cost',inf), nPop, 1);
    for i=1:nPop
        pop(i).Position = lo + rand(VarSize).*range;
        pop(i).Cost     = CostFunction(pop(i).Position);
        if pop(i).Cost < BestSol.Cost, BestSol = pop(i); end
    end
    BestCost = zeros(MaxIt,1);

    % ---- CCE state & opts
    cce_state = struct('t',1);
    cce_opts  = struct('tau',3,'K',[],'steps',5,'rho',0.7,'pick','min',...
                       'keep_one',true,'avoid_best',true);

    for it = 1:MaxIt
        for i=1:nPop
            x = pop(i).Position;

            % Mutation: DE/rand/1 (baseline)
            A = randperm(nPop); A(A==i) = [];
            a = A(1); b = A(2); c = A(3);
            v = pop(a).Position + F*(pop(b).Position - pop(c).Position);

            % Bounds before crossover
            v = max(v, lo); v = min(v, hi);

            % Binomial crossover
            z  = x;
            j0 = randi([1 numel(x)]);
            for j=1:numel(x)
                if j==j0 || rand<=pCR, z(j)=v(j); else, z(j)=x(j); end
            end

            % Selection (1 eval)
            New.Position = z;
            New.Cost     = CostFunction(z);
            if New.Cost < pop(i).Cost
                pop(i) = New;
                if pop(i).Cost < BestSol.Cost, BestSol = pop(i); end
            end
        end

        % ===== plug-in: Competitive Cluster Elimination (after selection)
        X = cat(1,pop.Position);
        f = [pop.Cost]';
        [X2, cce_state, info] = CCE(X, f, lo, hi, cce_state, cce_opts);
        if info.did_eliminate
            idx = info.replaced_idx(:)';
            for t = 1:numel(idx)
                ii = idx(t);
                pop(ii).Position = X2(ii,:);
                pop(ii).Cost     = inf;     % will be re-evaluated in next generation anyway
            end
        end

        BestCost(it) = BestSol.Cost;
    end

    BestScore = BestSol.Cost;
    BestPos   = BestSol.Position;
end

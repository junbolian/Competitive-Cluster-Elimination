function [pos, state, info] = CCE(pos, fvals, lb, ub, state, opts)
% CCE — Competitive Cluster Elimination (single plug-in module)
% Purpose: every TAU iterations, cluster the current population in decision
% space and eliminate the *worst cluster* by reinitializing a fraction of
% its members. No extra evaluations are performed here.
%
% Inputs
%   pos   : N x D population positions (already evaluated this gen)
%   fvals : N x 1 fitness (minimization)
%   lb/ub : 1 x D (or scalar) bounds
%   state : struct with persistent fields (may be empty on first call)
%           .t   (current iteration counter)
%   opts  : struct of options (all optional)
%           .tau        (cluster & eliminate every tau iters, default 3)
%           .K          (clusters; [] => min(8, ceil(sqrt(N))))
%           .steps      (# Lloyd steps for kmeans, default 5)
%           .rho        (fraction of WORST-CLUSTER members to reset, 0.7)
%           .pick       ('min' or 'median' cluster score; default 'min')
%           .keep_one   (true; always keep at least 1 survivor in that cluster)
%           .avoid_best (true; never eliminate the cluster containing global best)
%
% Outputs
%   pos   : possibly updated positions (restarts placed; not evaluated yet)
%   state : updated state (.t incremented)
%   info  : struct with diagnostics
%           .did_eliminate (logical), .worst_cluster, .replaced_idx (vector)
%
% Notes
% - Call CCE **after** you finished this generation's evaluations & updates,
%   so new positions will be evaluated naturally next generation.
% - For PSO: also reset pBest of replaced indices, and zero their velocities.
% - For DE: set pop(i).Cost=inf for replaced individuals (keeps eval count).
%
% Author: Junbo Jacob Lian (Jacoblian@u.northwestern.edu)

    if nargin < 6, opts = struct(); end
    if nargin < 5 || isempty(state), state = struct(); end
    if ~isfield(state,'t'), state.t = 1; end

    N = size(pos,1); D = size(pos,2);
    if isscalar(lb), lb = lb*ones(1,D); end
    if isscalar(ub), ub = ub*ones(1,D); end
    if size(lb,2)~=D || size(ub,2)~=D
        error('lb/ub must be 1xD or scalar');
    end

    % ---- defaults
    tau   = get_opt(opts,'tau',2);
    Kreq  = get_opt(opts,'K',[]);
    steps = get_opt(opts,'steps',5);
    rho   = get_opt(opts,'rho',0.9);
    pick  = get_opt(opts,'pick','min');   % 'min' (cluster-best) or 'median'
    keep_one   = get_opt(opts,'keep_one',true);
    avoid_best = get_opt(opts,'avoid_best',true);

    info = struct('did_eliminate',false,'worst_cluster',NaN,'replaced_idx',[]);

    % ---- only act every tau iterations
    if tau <= 0 || mod(state.t, tau) ~= 0
        state.t = state.t + 1;
        return;
    end

    % ---- build clusters (k-means++)
    K = Kreq;
    if isempty(K) || K<=0
        K = min(8, ceil(sqrt(N)));
    else
        K = max(1, min(K, N));
    end
    centers = kpp_init(pos, K);
    labels  = ones(N,1);
    for it = 1:steps
        D2 = sqdist(pos, centers);
        [~, labels] = min(D2, [], 2);
        for k=1:K
            idx = (labels==k);
            if any(idx)
                centers(k,:) = mean(pos(idx,:),1);
            else
                centers(k,:) = pos(randi(N),:);
            end
        end
    end

    % ---- per-cluster quality
    cluster_score = inf(K,1);
    counts        = zeros(K,1);
    for k=1:K
        idx = (labels==k);
        counts(k) = sum(idx);
        if counts(k)==0, cluster_score(k)=inf; continue; end
        fk = fvals(idx);
        switch lower(pick)
            case 'median', cluster_score(k) = median(fk);
            otherwise,      cluster_score(k) = min(fk); % 'min'
        end
    end

    % ---- find global-best cluster (for avoid_best)
    [~, igbest] = min(fvals);
    gk = labels(igbest);

    % ---- select worst cluster
    [~, worst_k] = max(cluster_score);
    if avoid_best && worst_k==gk
        % pick next worst that is not the gbest cluster
        tmp = cluster_score; tmp(gk) = -inf;
        [~, worst_k] = max(tmp);
    end

    % ---- indices in worst cluster
    I = find(labels==worst_k);
    if isempty(I) || counts(worst_k)<=1
        state.t = state.t + 1;
        return;
    end

    % ---- how many to replace
    m = max(1, round(rho * numel(I)));
    if keep_one
        m = min(m, numel(I)-1);
    else
        m = min(m, numel(I));
    end
    if m<=0
        state.t = state.t + 1;
        return;
    end

    % ---- choose which I to replace: worst m by fitness within cluster
    [~, ordLoc] = sort(fvals(I),'descend');   % worst first (max f)
    Irep = I(ordLoc(1:m));

    % ---- reinitialize
    rnd = lb + rand(m,D).*(ub - lb);
    pos(Irep,:) = rnd;

    % ---- out
    info.did_eliminate = true;
    info.worst_cluster = worst_k;
    info.replaced_idx  = Irep(:)';

    state.t = state.t + 1;
end

% --------------- helpers ---------------
function v = get_opt(s, name, def)
    if isfield(s,name) && ~isempty(s.(name)), v = s.(name);
    else, v = def; end
end

function C = kpp_init(X,K)
    [N,D] = size(X);
    C = zeros(K,D);
    i = randi(N); C(1,:) = X(i,:);
    if K==1, return; end
    D2 = sqdist(X, C(1,:));
    for k=2:K
        p = D2./max(sum(D2), eps);
        r = rand(); c = cumsum(p);
        i = find(r <= c, 1,'first'); if isempty(i), i=randi(N); end
        C(k,:) = X(i,:);
        D2 = min(D2, sqdist(X, C(k,:)));
    end
end

function D2 = sqdist(A,B)
    AA = sum(A.^2,2);
    BB = sum(B.^2,2)';
    D2 = max(0, AA + BB - 2*(A*B'));
end
